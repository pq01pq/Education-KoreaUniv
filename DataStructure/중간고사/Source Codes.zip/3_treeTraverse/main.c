#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "binaryTreeADT.h"
#include "stackADT.h"

void dfs(TREE_NODE* rootNode)
{
	// Write your code here.
}

int main()
{
	TREE_NODE* bt = buildDummyTree();

	dfs(bt);

	return 0;
}
